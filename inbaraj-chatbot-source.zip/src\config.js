export const WEBHOOK_URL = "https://athish-07.app.n8n.cloud/webhook/college-chat";
// Test URL:
// https://athish-07.app.n8n.cloud/webhook-test/college-chat
